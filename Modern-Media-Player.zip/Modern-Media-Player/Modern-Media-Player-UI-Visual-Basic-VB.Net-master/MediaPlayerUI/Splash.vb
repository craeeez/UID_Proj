﻿Public Class Splash
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Value += 1
        If ProgressBar1.Value <= 10 Then
            Label1.Text = "Initializing System"

        ElseIf ProgressBar1.Value <= 30 Then
            Label1.Text = "Loading all Components"


        ElseIf ProgressBar1.Value <= 50 Then
            Label1.Text = "Intigrating Database"


        ElseIf ProgressBar1.Value <= 70 Then
            Label1.Text = "Please Wait"


        ElseIf ProgressBar1.Value <= 100 Then
            Label1.Text = "Welcome To SPOOFY"

            If ProgressBar1.Value = 100 Then
                Label1.Text = "Initializing System"
                Timer1.Dispose()
                Me.Hide()
                loginform.Show()

            End If


        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub
End Class